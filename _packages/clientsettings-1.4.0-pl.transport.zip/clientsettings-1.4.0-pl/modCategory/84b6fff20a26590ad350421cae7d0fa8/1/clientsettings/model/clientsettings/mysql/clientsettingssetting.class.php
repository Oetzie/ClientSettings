<?php

/**
 * Client Settings
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */
    
require_once dirname(__DIR__) . '/clientsettingssetting.class.php';

class ClientSettingsSetting_mysql extends ClientSettingsSetting
{
}
