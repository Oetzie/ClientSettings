<?php

/**
 * Client Settings
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */
    
require_once dirname(__DIR__) . '/clientsettingscategory.class.php';

class ClientSettingsCategory_mysql extends ClientSettingsCategory
{
}
