<?php
	
	/**
	 * Client Settings
	 *
	 * Copyright 2018 by Oene Tjeerd de Bruin <modx@oetzie.nl>
	 */
	 
	require_once dirname(dirname(__FILE__)).'/clientsettingsvalues.class.php';
	
	class ClientSettingsValues_mysql extends ClientSettingsValues {}

?>