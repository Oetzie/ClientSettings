<?php

    /**
     * Client Settings
     *
     * Copyright 2018 by Oene Tjeerd de Bruin <modx@oetzie.nl>
     */
    
    $xpdo_meta_map = [
        'xPDOSimpleObject' => [
            'ClientSettingsCategories',
            'ClientSettingsSettings',
            'ClientSettingsValues'
        ]
    ];
	
?>