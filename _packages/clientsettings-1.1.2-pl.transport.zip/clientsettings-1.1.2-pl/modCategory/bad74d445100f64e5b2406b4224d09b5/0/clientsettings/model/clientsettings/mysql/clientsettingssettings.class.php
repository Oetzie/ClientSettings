<?php

    /**
     * Client Settings
     *
     * Copyright 2018 by Oene Tjeerd de Bruin <modx@oetzie.nl>
     */
    
    require_once dirname(dirname(__FILE__)).'/clientsettingssettings.class.php';
    
    class ClientSettingsSettings_mysql extends ClientSettingsSettings {}
	
?>