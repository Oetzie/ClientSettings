<?php

    /**
     * Client Settings
     *
     * Copyright 2018 by Oene Tjeerd de Bruin <modx@oetzie.nl>
     */
    
    require_once dirname(dirname(__FILE__)).'/clientsettingscategories.class.php';
    
    class ClientSettingsCategories_mysql extends ClientSettingsCategories {}
	
?>