<?php
	
	/**
	 * Client Settings
	 *
	 * Copyright 2018 by Oene Tjeerd de Bruin <modx@oetzie.nl>
	 */
	 
	require_once dirname(__DIR__) . '/clientsettingsvalue.class.php';
	
	class ClientSettingsValue_mysql extends ClientSettingsValue {}

?>