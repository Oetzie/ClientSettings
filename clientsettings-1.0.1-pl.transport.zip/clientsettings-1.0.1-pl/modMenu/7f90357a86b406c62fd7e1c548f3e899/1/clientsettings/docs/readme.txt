----------------------
ClientSettings
----------------------
Version: 1.0.0
Author: Oene Tjeerd de Bruin
Contact: info@oetzie.nl
----------------------

ClientSettings gives your client a user-friendly interface for making site
wide changes, while you as the administrator set up the different options
available to the end-user.

Possible uses include:
- Regularly update a slogan or tag-line in header or footer
- Keep contact details updated in one central location
- Update the email-address a form sends notifications to
