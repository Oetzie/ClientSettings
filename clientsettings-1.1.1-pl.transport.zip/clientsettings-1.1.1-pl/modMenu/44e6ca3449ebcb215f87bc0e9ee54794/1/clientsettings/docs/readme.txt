----------------------
Client Settings
----------------------
Version: 1.1.1
Author: Oene Tjeerd de Bruin
Contact: info@oetzie.nl
----------------------

This use this component the user needs to have the "clientsettings" permissions.
And the administrator user needs to have the "clientsettings_admin" permissions.